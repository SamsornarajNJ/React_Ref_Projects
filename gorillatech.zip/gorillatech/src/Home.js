import axios from "axios";
import React, { useEffect, useState } from "react";
import "./Home.css";

const Home = () => {
  const [qualifiedUsers, setQualifiedUsers] = useState([]);
  const getAllTasks = async () => {
    try {
      const response = await axios.get(
        "https://nextjs-boilerplate-five-plum-29.vercel.app/api/tasks"
      );
      const tasks = response.data;

      const uniqueUserIds = [...new Set(tasks.map((task) => task.userId))];

      let completedUserIds = uniqueUserIds.filter((userId) => {
        const userTasks = tasks.filter((task) => task.userId === userId);
        return userTasks.every((task) => task.completed);
      });

      const userRequests = completedUserIds.map((id) =>
        axios.get(
          `https://nextjs-boilerplate-five-plum-29.vercel.app/api/users/${id}`
        )
      );
      const userResponse = await Promise.all(userRequests);
      let usersData = userResponse.map((resp) => resp.data);
      usersData.sort(
        (a, b) =>
          a.name.localeCompare(b.name) ||
          a.id - b.id ||
          a.email.localeCompare(b.email)
      );

      setQualifiedUsers(usersData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getAllTasks();
  }, []);
  return (
    <div>
      <table>
        <tr>
          <th>User ID</th>
          <th>Name</th>
          <th>Email</th>
        </tr>
        {qualifiedUsers?.length > 0 ? (
          qualifiedUsers.map((user) => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.name}</td>
              <td>{user.email}</td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan="3">No qualified users found</td>
          </tr>
        )}
      </table>
    </div>
  );
};

export default Home;
